--*************************** Instructors Version ******************************--
-- Title:   DWStudentEnrollments ETL Process
-- Author: Felipe Gomez
-- Desc: This file perfom ETL processing for [DWStudentEnrollments] database. 
-- This file contains code used to clear and fill 
-- Note: Sproc code is simplfied for clarity
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created File
-- 2020-03-04,RRoot, Modified ETL code
-- 2023-11-27,FGomez,Modified ETL code
-- TODO: Complete logging, error handling, return codes, transaction support,and headers.
--**************************************************************************--
Use [master]
go
Select * From SysServers;
If Exists( Select * From SysServers Where srvname = 'SQLTEACHING.WESTUS.CLOUDAPP.AZURE.COM')
	SELECT('Linked Server is already setup')
Else 
	EXEC master.dbo.sp_addlinkedserver 
	  @server = N'SQLTEACHING.WESTUS.CLOUDAPP.AZURE.COM'
	, @srvproduct=N'SQL Server'

	EXEC master.dbo.sp_addlinkedsrvlogin 
	 @rmtsrvname=N'SQLTEACHING.WESTUS.CLOUDAPP.AZURE.COM'
	,@useself=N'False'
	,@locallogin=NULL
	,@rmtuser=N'BICert'
	,@rmtpassword=N'F@ll2023'
go

Use DWStudentEnrollments;
Go
Set NoCount On;
go

--********************************************************************--
-- 0) Create ETL metadata objects
--********************************************************************--
If NOT Exists(Select * From Sys.tables where Name = 'EtlLog')
  Create Table EtlLog
  (EtlLogID int identity Primary Key
  ,ETLDateAndTime datetime Default GetDate()
  ,ETLAction varchar(100)
  ,EtlLogMessage varchar(2000)
  );
go

-- Truncate Table EtlLog; -- Used to clear table

Create or Alter View vEtlLog
As
  Select
   EtlLogID
  ,ETLDate = Format(ETLDateAndTime, 'D', 'en-us')
  ,ETLTime = Format(Cast(ETLDateAndTime as datetime2), 'HH:mm:ss', 'en-us')
  ,ETLAction
  ,EtlLogMessage
  From EtlLog;
go


Create or Alter Proc pInsEtlLog
 (@ETLAction varchar(100), @EtlLogMessage varchar(2000))
--*************************************************************************--
-- Desc:This Sproc creates an admin table for logging ETL metadata. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As
Begin
  Declare @RC int = 0;
  Begin Try
    Begin Tran;
      Insert Into EtlLog
       (ETLAction,EtlLogMessage)
      Values
       (@ETLAction,@EtlLogMessage)
    Commit Tran;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
	Print Error_Message(); -- NOTE this is PRESENTATION CODE and will only be used for testing!
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Truncate Table ETLLog;
-- Exec pInsETLLog @ETLAction = 'Begin ETL',@ETLLogMessage = 'Start of ETL process' 
-- Select * From vEtlLog

--********************************************************************--
-- Pre-load tasks
--********************************************************************--
Go
Create or Alter Procedure pEtlDropFks
--*************************************************************************--
-- Desc:This sproc drops the foreign keys constraints. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
as
Begin 
	Declare @RC int = 0;
	Declare @Message varchar(1000) 
  Begin Try
	Alter Table FactEnrollments Drop Constraint FK_FactEnrollments_DimDates;
	Alter Table FactEnrollments Drop Constraint FK_FactEnrollments_DimStudents;
	Alter Table FactEnrollments DRop Constraint FK_FactEnrollments_DimClasses;
	Set @Message = 'Foreign Keys removed from tables';
	Exec pInsEtlLog
 	       @ETLAction = 'pEtlDropFks'
 	      ,@EtlLogMessage = @Message;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
    Exec pInsEtlLog 
         @ETLAction = 'pEtlDropFks'
        ,@EtlLogMessage = @ErrorMessage;
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlDropFks; Select * From vEtlLog;

Go
Create or Alter Procedure pEtlTruncateTables
--*************************************************************************--
-- Desc:This sproc truncates all data and reset the Identity Auto Number
--      from the tables
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
as
Begin 
	Declare @RC int = 0;
	Declare @Message varchar(1000) 
  Begin Try
	Truncate Table FactEnrollments;
	Truncate Table DimStudents;
	Truncate Table DimClasses;
	Truncate Table DimDates;
	Set @Message = 'Data removed from all tables';
	Exec pInsEtlLog
 	       @ETLAction = 'pEtlTrucateTables'
 	      ,@EtlLogMessage = @Message;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
    Exec pInsEtlLog 
         @ETLAction = 'pEtlTruncateTables'
        ,@EtlLogMessage = @ErrorMessage;
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlTruncateTables; Select * From vEtlLog;

--********************************************************************--
-- Load dimension tables
--********************************************************************--
-- DimDates should go first due to the lookups in other tables
Go
Create or Alter Proc pEtlDimDates
As 
Begin
  Declare @RC int = 1;
  Declare @Message varchar(1000) 
  Set NoCount On; -- This will remove the 1 row affected msg in the While loop;
  Begin Try
 	  -- Create variables to hold the start and end date
	  Declare @StartDate datetime = '01/01/2015';
	  Declare @EndDate datetime = '12/31/2025'; 
	  Declare @DateInProcess datetime;
      Declare @TotalRows int = 0;

	  -- Use a while loop to add dates to the table
	  Set @DateInProcess = @StartDate;

	  While @DateInProcess <= @EndDate
	    Begin
	      -- Add a row into the date dimensiOn table for this date
	     Begin Tran;
	       Insert Into DimDates 
	       ( [DateKey], [FullDate], [USADateName], [MonthKey], [MonthName], [QuarterKey], [QuarterName], [YearKey], [YearName] )
	       Values ( 
	   	     Cast(Convert(nvarchar(50), @DateInProcess , 112) as int) -- [DateKey]
	        ,@DateInProcess -- [FullDate]
	        ,DateName( weekday, @DateInProcess ) + ', ' + Convert(nvarchar(50), @DateInProcess , 110) -- [USADateName]  
	        ,Left(Cast(Convert(nvarchar(50), @DateInProcess , 112) as int), 6) -- [MonthKey]   
	        ,DateName( MONTH, @DateInProcess ) + ', ' + Cast( Year(@DateInProcess ) as nVarchar(50) ) -- [MonthName]
	        , Cast(Cast(YEAR(@DateInProcess) as nvarchar(50))  + '0' + DateName( QUARTER,  @DateInProcess) as int) -- [QuarterKey]
	        ,'Q' + DateName( QUARTER, @DateInProcess ) + ', ' + Cast( Year(@DateInProcess) as nVarchar(50) ) -- [QuarterName] 
	        ,Year( @DateInProcess ) -- [YearKey]
	        ,Cast( Year(@DateInProcess ) as nVarchar(50) ) -- [YearName] 
	        ); 
	       -- Add a day and loop again
	       Set @DateInProcess = DateAdd(d, 1, @DateInProcess);
	     Commit Tran;
      Set @TotalRows += 1;
	  End -- While
    
	-- 2e) Add additional lookup values to DimDates
	 Begin Tran;
	 Insert Into DimDates 
	   ( [DateKey]
	   , [FullDate]
	   , [USADateName]
	   , [MonthKey]
	   , [MonthName]
	   , [QuarterKey]
	   , [QuarterName]
	   , [YearKey]
	   , [YearName] )
	   Select 
		 [DateKey] = -1
	   , [FullDate] = '19000101'
	   , [USADateName] = Cast('Unknown Day' as nVarchar(50) )
	   , [MonthKey] = -1
	   , [MonthName] = Cast('Unknown Month' as nVarchar(50) )
	   , [QuarterKey] =  -1
	   , [QuarterName] = Cast('Unknown Quarter' as nVarchar(50) )
	   , [YearKey] = -1
	   , [YearName] = Cast('Unknown Year' as nVarchar(50) )
	   Union
	   Select 
		 [DateKey] = -2
	   , [FullDate] = '19000102'
	   , [USADateName] = Cast('Corrupt Day' as nVarchar(50) )
	   , [MonthKey] = -2
	   , [MonthName] = Cast('Corrupt Month' as nVarchar(50) )
	   , [QuarterKey] =  -2
	   , [QuarterName] = Cast('Corrupt Quarter' as nVarchar(50) )
	   , [YearKey] = -2
	   , [YearName] = Cast('Corrupt Year' as nVarchar(50) );
	  Commit Tran;
    Set @TotalRows += 2;

	Set @Message = 'Filled DimDates (' + Cast(@TotalRows as varchar(100)) + ' rows)';
	Exec pInsEtlLog
	     @ETLAction = 'pEtlDimDates'
	    ,@EtlLogMessage = @Message;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback Tran;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
	  Exec pInsEtlLog
	        @ETLAction = 'pEtlDimDates'
	       ,@EtlLogMessage = @ErrorMessage;
    Set @RC = -1;
  End Catch
  Set NoCount Off;
  Return @RC;
End
Go
-- Exec pEtlDimDates; Select * From DimDates;Select * From vEtlLog;

Go
Create or Alter View vEtlDimClasses
AS
	Select 
	 [ClassID] = c.Id
	,[ClassName] = c.Name
	,[DepartmentID] = d.[ID]
	,[DepartmentName] = d.[Name]
	,[ClassStartDate] = Cast(StartDate as Date)
	,[ClassEndDate] = Cast(EndDate as Date)
	,[CurrentPrice] = c.Price
	,[MaxCourseEnrollment]= c.MaxSize
	,[ClassroomID] = cr.Id
	,[ClassroomName] = cr.Name
	,[MaxClassroomSize] = cr.MaxSize
    From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Classes] AS c
	JOIN [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Departments] AS d
	ON c.[DepartmentId] = d.[Id]
	JOIN [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Classrooms] AS cr
	ON c.[ClassroomId] = CR.[Id];
Go

Go
Create or Alter Procedure pEtlDimClasses
 --*************************************************************************--
-- Desc:This Sproc fills the DimClasses table. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As 
Begin 
	Declare @RC int = 0;
	Declare @Message varchar(1000)
    Begin Try
	  Begin Tran;
		Insert Into DimClasses 
		(ClassID
		, ClassName
		, DepartmentID
		, DepartmentName
		, ClassStartDate
		, ClassEndDate
		, CurrentClassPrice
		, MaxCourseEnrollment
		, ClassroomID
		, ClassroomName
		, MaxClassroomSize)
		Select * From vEtlDimClasses;

		Set @Message = 'Filled DimClasses (' + Cast(@@RowCount as varchar(100)) + ' rows)';
	  Commit Tran;

      -- Todo: Add Logging Code
	  Exec pInsEtlLog
		    @ETLAction = 'pEtlDimClasses'
		   ,@EtlLogMessage = @Message;

    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;

      -- Todo: Add Logging Code
	  Declare @ErrorMessage nvarchar(1000) = Error_Message();
	  Exec pInsEtlLog
			@ETLAction = 'pEtlDimClasses'
		   ,@EtlLogMessage = @ErrorMessage;

   Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlDimClasses; Select * From DimClasses;Select * From vEtlLog;

Go
Create or Alter View vEtlDimStudents
AS
Select [StudentID] = s.Id
      ,[StudentFullName] = Cast((s.FirstName + ' ' + s.LastName) as nVarChar(200))
      ,[StudentEmail] = s.Email
  From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Students] as s;
Go

Go
Create or Alter Procedure pEtlDimStudents
--*************************************************************************--
-- Desc:This Sproc fills the DimStudents table. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As 
Begin 
	Declare @RC int = 0;
	Declare @Message varchar(1000)
    Begin Try
	  Begin Tran;
		Insert Into DimStudents (StudentID, StudentFullName, StudentEmail )
		Select StudentID, StudentFullName, StudentEmail From vEtlDimStudents

		Set @Message = 'Filled DimStudents (' + Cast(@@RowCount as varchar(100)) + ' rows)';
	  Commit Tran;

      -- Todo: Add Logging Code
	  Exec pInsEtlLog
		    @ETLAction = 'pEtlDimStudents'
		   ,@EtlLogMessage = @Message;

    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;

      -- Todo: Add Logging Code
	  Declare @ErrorMessage nvarchar(1000) = Error_Message();
	  Exec pInsEtlLog
			@ETLAction = 'pEtlDimStudents'
		   ,@EtlLogMessage = @ErrorMessage;

   Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlDimStudents; Select * From DimStudents;Select * From vEtlLog;


--********************************************************************--
-- Load Fact Tables
--********************************************************************--

/*
  Select 
	 [EnrollmentID] = e.Id
	,[EnrollmentDateTime] = e.Date
	,[EnrollmentDate] = Cast(e.Date as date)
  From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Enrollments] AS e

    Select 
	 [EnrollmentID] = e.Id
	,[EnrollmentDateTime] = e.Date
	,[EnrollmentDate] = Cast(e.Date as date)
	,[EnrollmentDateKey] = dd.[DateKey]
  From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Enrollments] AS e
  JOIN [DWStudentEnrollments].[dbo].[DimDates] AS dd
    ON Cast(e.[Date] as date) = Cast(dd.[FullDate] as date)

  Select 
	 [EnrollmentID] = e.Id
	,[EnrollmentDateTime] = e.Date
	,[EnrollmentDate] = Cast(e.Date as date)
	,[EnrollmentDateKey] = dd.[DateKey]
	,[StudentKey] = s.[StudentKey]
	,[StudentID] = s.StudentID
  From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Enrollments] AS e
  JOIN [DWStudentEnrollments].[dbo].[DimDates] AS dd
    ON Cast(e.[Date] as date) = Cast(dd.[FullDate] as date)
  JOIN [DWStudentEnrollments].[dbo].[DimStudents] AS s
    ON e.[StudentId] = s.[StudentID]

*/

Go
Create or Alter View vEtlFactEnrollments
AS
  Select 
	 [EnrollmentID] = e.Id
	,[EnrollmentDateTime] = e.Date
	,[EnrollmentDate] = Cast(e.Date as date)
	,[EnrollmentDateKey] = dd.[DateKey]
	,[StudentKey] = s.[StudentKey]
	,[StudentID] = s.StudentID
	,[ClassKey] = c.[ClassKey] 
	,[ClassID] = c.ClassID
	,[ActualEnrollmentPrice] = e.Price
  From [sqlteaching.westus.cloudapp.azure.com].[StudentEnrollments].[dbo].[Enrollments] AS e
  
  JOIN [DWStudentEnrollments].[dbo].[DimDates] AS dd
    ON Cast(e.[Date] as date) = Cast(dd.[FullDate] as date)
  
  JOIN [DWStudentEnrollments].[dbo].[DimStudents] AS s
    ON e.[StudentId] = s.[StudentID]

  JOIN [DWStudentEnrollments].[dbo].[DimClasses] AS c
    ON e.[ClassId] = c.[ClassID];
Go

Go
Create or Alter Procedure pEtlFactEnrollments
--*************************************************************************--
-- Desc:This Sproc fills the FactEnrollments table. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As 
Begin
  Declare @RC int = 1;
  Declare @Message varchar(1000);
  Begin Try
   Begin Tran;
	Insert Into [dbo].[FactEnrollments] 
	(EnrollmentID, EnrollmentDateKey, StudentKey, ClassKey, ActualEnrollmentPrice)
	Select EnrollmentID, EnrollmentDateKey, StudentKey, ClassKey, ActualEnrollmentPrice From vEtlFactEnrollments

	Set @Message = 'Filled FactEnrollments (' + CAST(@@RowCount as varchar(100)) + ' rows)';
	    Commit Tran;
		Exec pInsEtlLog
			@ETLAction = 'pEtlFactEnrollments'
		   ,@EtlLogMessage = @Message;

    Set @RC = 1
  End Try
  Begin Catch
	If @@TRANCOUNT > 0 Rollback;

	Declare @ErrorMessage nvarchar(1000) = Error_Message();
	Exec pInsEtlLog
		@ETLAction = 'pEtlFactEnrollments'
	   ,@EtlLogMessage = @ErrorMessage;

    Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlFactEnrollments; Select * From FactEnrollments; Select * From vEtlLog;

--********************************************************************--
-- Post-load Tasks
--********************************************************************--
Go
Create or Alter Procedure pEtlReplaceFKs
--*************************************************************************--
-- Desc:This Sproc Replaces the Foreign Keys Constraints. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
as
Begin 
	Declare @RC int = 1;
	Declare @Message varchar(1000);
  Begin Try
	Alter Table FactEnrollments Add Constraint FK_FactEnrollments_DimDates
	  Foreign Key(EnrollmentDateKey) References DimDates(DateKey);
	Alter Table FactEnrollments Add Constraint FK_FactEnrollments_DimStudents
	  Foreign Key([StudentKey]) References DimStudents(StudentKey);
	Alter Table FactEnrollments Add Constraint FK_FactEnrollments_DimClasses
	  Foreign Key([ClassKey]) References DimClasses(ClassKey);
	Set @Message = 'Foreign Keys replaced on all tables';
	Exec pInsEtlLog
 	       @ETLAction = 'pEtlReplaceFKs'
 	      ,@EtlLogMessage = @Message;
    Set @RC = 1;
  End Try
  Begin Catch
    If @@TRANCOUNT > 0 Rollback;
    Declare @ErrorMessage nvarchar(1000) = Error_Message();
    Exec pInsEtlLog 
         @ETLAction = 'pEtlReplaceFKs'
        ,@EtlLogMessage = @ErrorMessage;
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go
-- Exec pEtlReplaceFKs; Select * From vEtlLog



--********************************************************************--
-- Review the results of this script
--********************************************************************--
Go
Exec pInsETLLog @ETLAction = 'Begin ETL', @EtlLogMessage = 'Start of ETL process' 
Exec pEtlDropFks; 
Exec pEtlTruncateTables;
Exec pEtlDimDates; Select top 10 * From vDimDates;
Exec pEtlDimClasses; Select * From vDimClasses;
Exec pEtlDimStudents; Select * From vDimStudents;
Exec pEtlFactEnrollments; Select * From vFactEnrollments;
Exec pEtlReplaceFKs;
Exec pInsETLLog @ETLAction = 'End ETL', @EtlLogMessage = 'End of ETL process' 
Select * From vEtlLog



