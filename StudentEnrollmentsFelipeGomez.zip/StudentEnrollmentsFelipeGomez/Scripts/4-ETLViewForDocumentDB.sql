--*************************** Instructors Version ******************************--
-- Title:   DWStudentEnrollments ETL Views for DocumentDB Model
-- Author: Felipe Gomez
-- Desc: This file creates [DWStudentEnrollments] ETL Views for DocumentDB Model. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created File
-- 2020-03-04,RRoot, Modified ETL code
-- 2023-11-29,FGomez,Ran Code
--**************************************************************************--
USE DWStudentEnrollments;
Go
Set NoCount On;

-- Step 1: Figure out your transformation code
Select Distinct
 [CourseName] = ClassName
, dc.MaxCourseEnrollment 
,[AvaliableSpaces] = (dc.MaxCourseEnrollment - Count(fe.Studentkey) Over(Partition By fe.ClassKey))
From FactEnrollments as fe Join DimClasses as dc
  On fe.ClassKey = dc.ClassKey


-- Step 2: Create your transformation statement
-- Now, we start building our transformation statement.
Select Distinct [StudentInCourseKPI] = Case
When (dc.MaxCourseEnrollment * .75) > (dc.MaxCourseEnrollment - Count(fe.Studentkey) Over(Partition By fe.ClassKey))
Then 1 -- Good enrollment
When (dc.MaxCourseEnrollment * .25) < (dc.MaxCourseEnrollment - Count(fe.Studentkey) Over(Partition By fe.ClassKey))
Then -1 -- Poor enrollment
Else 0 -- Average enrollment
End
From FactEnrollments as fe Join DimClasses as dc
On fe.ClassKey = dc.ClassKey


-- Step 3: Save the transformation statement in a function or view
Go
Create or Alter Function dbo.fKPIMaxLessCurrentEnrollments(@ClassKey int)
Returns int
AS
Begin
  Return(
   Select Distinct [StudentInCourseKPI] = Case
   When (dc.MaxCourseEnrollment * .75) > (dc.MaxCourseEnrollment - Count(fe.Studentkey) Over(Partition By fe.ClassKey))
    Then 1 -- Good enrollment
   When (dc.MaxCourseEnrollment * .25) < (dc.MaxCourseEnrollment - Count(fe.Studentkey) Over(Partition By fe.ClassKey))
    Then -1 -- Poor enrollment
   Else 0 -- Average enrollment
  End
  From FactEnrollments as fe Join DimClasses as dc
    On fe.ClassKey = dc.ClassKey
  Where fe.ClassKey = @ClassKey
  )
End;
Go
Select dbo.fKPIMaxLessCurrentEnrollments(1);
Select dbo.fKPIMaxLessCurrentEnrollments(2);
Go
-- Danger! Only for testing on Dev server
Update DimClasses -- for testing
Set MaxCourseEnrollment = 5
Go
Select * From DimClasses
Select dbo.fKPIMaxLessCurrentEnrollments(1);
Select dbo.fKPIMaxLessCurrentEnrollments(2);
Go

-- Reset after test
Update DimClasses -- for testing
Set MaxCourseEnrollment = 32
Go
Select * From DimClasses
Select dbo.fKPIMaxLessCurrentEnrollments(1);
Select dbo.fKPIMaxLessCurrentEnrollments(2);
Go


Create or Alter View vETLDocumentDB
AS
  With CteDistinctClassDataBeforeID
  As(
  Select Distinct
   -- [_id] = ROW_NUMBER() Over(Order By fe.ClassKey) -- Ig 
   [ClassKey] = dc.ClassKey -- Needed to sort data for adding a _id row number.
  ,[ClassName] = ClassName
  ,[ClassStartDate] = ClassStartDate
  ,[ClassEndDate] = ClassEndDate
  ,[MaxCourseEnrollment] = MaxCourseEnrollment
  ,[CurrentClassPrice] = CurrentClassPrice
  ,[AvgEnrollmentPrice] = AVG(fe.ActualEnrollmentPrice) Over(Partition By fe.ClassKey) 
  ,[CourseEnrollmentLevelKPI] = dbo.fKPIMaxLessCurrentEnrollments(fe.ClassKey)
  From FactEnrollments as fe
  Join DimDates as dd
    On fe.EnrollmentDateKey = dd.DateKey
  Join DimClasses as dc
    On fe.ClassKey = dc.ClassKey
  Join DimStudents as ds
    On fe.StudentKey = ds.StudentKey
) Select 
[_id] = ROW_NUMBER() Over(Order By ClassKey)
  ,[ClassName]
  ,[ClassStartDate]
  ,[ClassEndDate]
  ,[MaxCourseEnrollment]
  ,[CurrentClassPrice]
  ,[AvgEnrollmentPrice]
  ,[CourseEnrollmentLevelKPI]
  From CteDistinctClassDataBeforeID

Go
-- Check the view: 
Select * From vETLDocumentDB; -- Now export data to CSV

-- You can import JSON data instead. However, the SQL Server For JSON command makes 
-- a single document instead of many documents with does not work for our MongoDB database!
Select * From vETLDocumentDB For JSON Path;