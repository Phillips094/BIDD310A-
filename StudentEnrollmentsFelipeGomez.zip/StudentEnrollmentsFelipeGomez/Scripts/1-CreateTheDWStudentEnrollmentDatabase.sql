--**************************************************************************--
-- Title: Create the DWStudentEnrollments database
-- Author: Felipe Gomez
-- Desc: This file will drop and create the DWStudentEnrollments database. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created starter code
-- 2023-11-18,FGomez,Modified DW creation code
--**************************************************************************--
Set NoCount On;

USE [master]
If Exists (Select Name from SysDatabases Where Name = 'DWStudentEnrollments')
  Begin
   ALTER DATABASE DWStudentEnrollments SET SINGLE_USER WITH ROLLBACK IMMEDIATE
   DROP DATABASE DWStudentEnrollments
  End
Go
Create Database DWStudentEnrollments;
Go
USE DWStudentEnrollments;


--********************************************************************--
-- Create the Tables
--********************************************************************--
Create Table DimClasses 
([ClassKey] int Identity Not Null Constraint pkDimClasses Primary Key
,[ClassID] int Not Null
,[ClassName] nvarchar(200) Not nUll
,[ClassStartDate] date Not Null
,[ClassEndDate] date Not Null
,[CurrentClassPrice] money Not Null
,[MaxCourseEnrollment] int Not Null
,[DepartmentID] int Not Null
,[DepartmentName] nvarchar(200) Not NUll
,[ClassroomID] int Not Null
,[ClassroomName] nvarchar(200) Not Null
,[MaxClassroomSize] int Not Null
);
Go

Create Table DimStudents 
([StudentKey] int Identity Not Null Constraint pkDimStudents Primary Key
,[StudentID] int Not Null
,[StudentFullName] nvarchar(200) Not Null
,[StudentEmail] nvarchar(200) Not Null
);
Go

Create Table DimDates 
([DateKey] int Not Null Constraint pkDimDates Primary Key
,[FullDate] date Not Null
,[USADateName] nvarchar(200) Not Null
,[MonthKey] int Not Null
,[MonthName] nvarchar(200) Not Null
,[QuarterKey] int Not Null
,[QuarterName] nvarchar(200) Not Null
,[YearKey] int Not Null
,[YearName] nvarchar(200) Not Null
);
Go

Create Table FactEnrollments 
([EnrollmentID] int Not Null
,[EnrollmentDateKey] int Not Null
,[StudentKey] int Not Null
,[ClassKey] int Not Null
,[ActualEnrollmentPrice] money Not Null
Constraint pkFactEnrollments Primary Key([EnrollmentID], [EnrollmentDateKey], [StudentKey], [ClassKey] )
);
Go
--********************************************************************--
-- Create the FOREIGN KEY CONSTRAINTS
--********************************************************************--
Alter Table FactEnrollments
	Add Constraint FK_FactEnrollments_DimDates
	Foreign Key ([EnrollmentDateKey]) References DimDates([DateKey]);
Go

Alter Table FactEnrollments
	Add Constraint FK_FactEnrollments_DimStudents
	Foreign Key ([StudentKey]) References DimStudents([StudentKey]);
Go

Alter Table FactEnrollments
	Add Constraint FK_FactEnrollments_DimClasses
	Foreign Key ([ClassKey]) References DimClasses([ClassKey]);
Go

--********************************************************************--
-- Create the Abstraction Layers
--********************************************************************--

-- Base Views
Create or Alter View vDimClasses AS (
SELECT TOP 100 PERCENT
 [ClassKey]
,[ClassID]
,[ClassName]
,[ClassStartDate]
,[ClassEndDate]
,[CurrentClassPrice]
,[MaxCourseEnrollment]
,[DepartmentID]
,[DepartmentName]
,[ClassroomID]
,[ClassroomName]
,[MaxClassroomSize]
FROM DimClasses
)
GO

Create or Alter View vDimStudents AS (
SELECT TOP 100 PERCENT
 [StudentKey]
,[StudentID]
,[StudentFullName]
,[StudentEmail]
FROM DimStudents
)
GO

Create or Alter View vDimDates AS (
SELECT TOP 100 PERCENT
 [DateKey]
,[FullDate]
,[USADateName]
,[MonthKey]
,[MonthName]
,[QuarterKey]
,[QuarterName]
,[YearKey]
,[YearName]
FROM DimDates
)
GO

Create or Alter View vFactEnrollments AS (
SELECT TOP 100 PERCENT
 [EnrollmentID]
,[EnrollmentDateKey]
,[StudentKey]
,[ClassKey]
,[ActualEnrollmentPrice]
FROM FactEnrollments
)
GO

-- Metadata View
Go
Create or Alter View vMetaDataStudentEnrollments
As
Select Top 100 Percent
 [Source Table] = DB_Name() + '.' + SCHEMA_NAME(tab.[schema_id]) + '.' + object_name(tab.[object_id])
,[Source Column] =  col.[Name]
,[Source Type] = Case 
				When t.[Name] in ('char', 'nchar', 'varchar', 'nvarchar' ) 
				  Then t.[Name] + ' (' +  format(col.max_length, '####') + ')'                
				When t.[Name]  in ('decimal', 'money') 
				  Then t.[Name] + ' (' +  format(col.[precision], '#') + ',' + format(col.scale, '#') + ')'
				 Else t.[Name] 
                End 
,[Source Nullability] = iif(col.is_nullable = 1, 'Null', 'Not Null') 
From Sys.Types as t 
Join Sys.Columns as col 
 On t.system_type_id = col.system_type_id 
Join Sys.Tables tab
  On tab.[object_id] = col.[object_id]
And t.name <> 'sysname'
Order By [Source Table], col.column_id; 
go
Select * From vMetaDataStudentEnrollments;
