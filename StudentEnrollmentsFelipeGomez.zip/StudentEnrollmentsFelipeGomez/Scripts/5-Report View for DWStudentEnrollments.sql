--*************************** Instructors Version ******************************--
-- Title:   DWStudentEnrollments ETL Views for DocumentDB
-- Author: Felipe Gomez
-- Desc: This file creates [DWStudentEnrollments] Reporting Functions and Views for DWStudentEnrollment. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created File
-- 2020-03-04,RRoot, Modified ETL code
-- 2023-11-30,FGomez,Modified ETL Code and Ran Code
--**************************************************************************--

USE DWStudentEnrollments;
Go

Create or Alter View vRptStudentEnrollments
AS
  Select 
   [EnrollmentID] = EnrollmentID 
	,[FullDateTime] = Cast(FullDate as Date)
	,[Date] =[USADateName]
	,[Month] = [MonthName]
	,[Quarter] = QuarterName
	,[Year] = YearName
	,[ClassID] = ClassID
  ,[Course] = ClassName
  ,[DepartmentID] = DepartmentID
  ,[Department]= DepartmentName
  ,[ClassStartDate] = ClassStartDate
  ,[ClassEndDate] = ClassEndDate
  ,[CurrentCoursePrice] = CurrentClassPrice -- Changed Column Name
  ,[MaxCourseEnrollment] = MaxCourseEnrollment
  ,[ClassroomID] = ClassroomID
  ,[Classroom] = ClassroomName
  ,[MaxClassroomSize] = MaxClassroomSize
  ,[StudentID] = StudentID
  ,[StudentFullName] = StudentFullName
  ,[StudentEmail] = StudentEmail
  ,[EnrollmentsPerCourse] = Count(fe.Studentkey) Over(Partition By fe.ClassKey)
  ,[CourseEnrollmentLevelKPI] = dbo.fKPIMaxLessCurrentEnrollments(fe.ClassKey)
  ,[ActualEnrollmentPrice] = fe.ActualEnrollmentPrice
  From FactEnrollments as fe
  Join DimDates as dd
    On fe.EnrollmentDateKey = dd.DateKey
  Join DimClasses as dc
    On fe.ClassKey = dc.ClassKey
  Join DimStudents as ds
    On fe.StudentKey = ds.StudentKey;
Go
Select * From vRptStudentEnrollments;
