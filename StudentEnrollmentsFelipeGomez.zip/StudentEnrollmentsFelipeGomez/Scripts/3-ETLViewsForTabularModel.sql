--*************************** Instructors Version ******************************--
-- Title:   DWStudentEnrollments ETL Views for Tabular Model
-- Author: Felipe Gomez
-- Desc: This file creates [DWStudentEnrollments] ETL Views for Tabular Model. 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created File
-- 2020-03-04,RRoot, Modified ETL code
-- 2023-11-29,FGomez,Modified ETL code and Ran Code
--**************************************************************************--
USE DWStudentEnrollments;
Go
Set NoCount On;
Go

-- Step 1: Figure out your transformation code

-- Earlier version of SSAS had issue with the ISO date format yyyymmdd.
-- To fix this we can try a transformation like this:
Select Cast(20200101 as date) 
-- However, we get this: Explicit conversion from data type int to date is not allowed.
Go

-- So, instead we do this:
Select Cast('20200101' as date)
Select Cast(Cast(20200101 as varchar(10)) as date)
Go

-- However, if you have data like -1 and -2 we get
Select Cast(Cast(-1 as varchar(10)) as date)
-- This error: Conversion failed when converting date and/or time from character string.
Go

-- Step 2: Create your transformation statement
-- Now, we start building our transformation statement.
Select 
 [DateKey] = Cast(Cast(DateKey as varchar(10)) as date)
-- Or just do this... ,DateKey = FullDate
,[FullDate]
,[USADateName]
,[MonthKey] -- Needed for sorting
,[MonthName]
,[QuarterKey] -- Needed for sorting
,[QuarterName]
,[YearKey] -- Needed for sorting
,[YearName]
From DimDates
Where DateKey Not In (-1,-2)

-- Step 3: Save the transformation statement in a view
Go
Create or Alter View vTabularETLDimDates
AS
  Select 
	 [DateKey] = Cast(Cast(DateKey as varchar(10)) as date)
	,[FullDate]
	,[USADateName]
	,[MonthKey]
	,[MonthName]
	,[QuarterKey]
	,[QuarterName]
	,[YearKey]
	,[YearName]
  From DimDates
  Where DateKey Not In (-1,-2)
Go
-- Check the view: Select * From vTabularETLDimDates

Create or Alter View vTabularETLDimClasses
AS
  Select
   [ClassKey]  
  ,[ClassID]
  ,[ClassName]
  ,[DepartmentID]
  ,[DepartmentName]
  ,[ClassStartDate]
  ,[ClassEndDate]
  ,[CurrentClassPrice]
  ,[MaxCourseEnrollment]
  ,[ClassroomID]
  ,[ClassroomName]
  ,[MaxClassroomSize]
  From DimClasses
Go
-- Check the view: Select * From vTabularETLDimClasses

Create or Alter View vTabularETLDimStudents
AS
  Select 
   [StudentKey]
  ,[StudentID]
  ,[StudentFullName]
  ,[StudentEmail]
  From DimStudents;
Go
-- Check the view: Select * From vTabularETLDimStudents

-- We need to cast the Enrollment date key to match the date dimension view
Create or Alter View vTabularETLFactEnrollments
AS
  Select 
   [EnrollmentID]
  ,[EnrollmentDateKey] = Cast(Cast(EnrollmentDateKey as varchar(10)) as date)
  ,[StudentKey]
  ,[ClassKey]
  ,[ActualEnrollmentPrice]
  From FactEnrollments
Go
-- Check the view: Select * From vTabularETLFactEnrollments

Select * From vTabularETLDimDates;
Select * From vTabularETLDimClasses;
Select * From vTabularETLDimStudents;
Select * From vTabularETLFactEnrollments;