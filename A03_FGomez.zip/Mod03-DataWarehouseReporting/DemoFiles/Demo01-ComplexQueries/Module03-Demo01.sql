--*************************************************************************--
-- Title: Module03-Demo01: Creating Complex Reporting Queries 
-- Desc: An example of how to create complex queries to get reporting results.
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created File
--*************************************************************************--
Use EmployeeProjects;
go

-- Let's look at the data before we start writing test quieries
Create or Alter View vHoursByProjectAndCategory
As
  Select
     CategoryID = c.ID
    ,CategoryName = c.Name
    ,ProjectID = p.ID
    ,ProjectName = p.Name
    ,HoursWorked = Hrs
  From [EmployeeProjectHours] as eph
  Join [Projects] as p 
    On eph.ProjectID = p.ID
  Join ProjectsCategories as pc 
    On p.ID = pc.ProjectID
  Join [Categories] as c 
    On pc.CategoryID = c.ID;
go

Select * From vHoursByProjectAndCategory Order By CategoryName;
go

-- Note that there are 8 hours in category DW DB and 7 in Web App
-- This is important because of the many to many relationship between projects and categories
-- Remember, if we are not careful will will get double-counts in our report data

-- Test Query 1: SELECT the total hours worked on all projects. Which of these are correct?
If Object_ID('tempdb..#TotalByProject') is not null Drop Table #TotalByProject;
If Object_ID('tempdb..#TotalByCategory') is not null Drop Table #TotalByCategory;
go
Select 
  [TotalHours] = Sum(Hrs)
Into #TotalByProject
From EmployeeProjectHours
go
Select 
  [TotalHours] = Sum(HoursWorked)
Into #TotalByCategory
From vHoursByProjectAndCategory
go
Select [TotalHours] From #TotalByProject;
Select [TotalHours] From #TotalByCategory;

-- Now, let's SELECT the total hours worked along with the total hours worked by CATEGORIES.
-- We will use a variable to capture the total hours

-- This looks like it would work, but look at the percentages! See how they are totals for the Project, not the Categories?

Declare @TotalHours int
  Select @TotalHours = Sum(Hrs) From [EmployeeProjectHours]; --< Note the table we are using

Select 
   [CategoryName] = c.Name
  ,[TotalHoursByCategory] = Sum(Hrs)
  ,[TotalHours] = @TotalHours
  ,[PercentByCategory] = Format(1. * (Sum(Hrs)) / @TotalHours, '00.00%') 
From [EmployeeProjectHours] as eph
Join [Projects] as p On eph.ProjectID = p.ID
Join ProjectsCategories as pc On p.ID = pc.ProjectID
Join [Categories] as c On c.ID  =  pc.CategoryID
Group By c.Name
Order By c.Name;
go

----------------------------------------------------------------------------------------------
--CategoryName	    TotalHoursByCategory	TotalHours	PercentByCategory
--DW Implementation	8.00	                10	        80.00%
--DW Planning	      7.00	                10	        70.00%
----------------------------------------------------------------------------------------------

-- So, let's try using our Categories temp table instead...
Declare @TotalHoursByCategory int
  Select @TotalHoursByCategory = [TotalHours] From #TotalByCategory;  --< Note the table we are using

Select
   [CategoryID] = c.ID -- Will be handy for a later join!
  ,[CategoryName] = c.Name
  ,[TotalHoursByCategory] = Sum(Hrs)
  ,[TotalHours] = @TotalHoursByCategory
From [EmployeeProjectHours] as eph
Join [Projects] as p On eph.ProjectID = p.ID
Join ProjectsCategories as pc On p.ID = pc.ProjectID
Join [Categories] as c On c.ID = pc.CategoryID
Group By c.ID, c.Name
Order By c.ID;
go

-- OK, that is better! Now, let's save our results in a temp table
-- and ADD a column that show the reletive percentages while we are at it

If (Object_ID('tempdb..#CategoryContributions') is not null) Drop Table #CategoryContributions;
go
Declare @TotalHoursByCategory int
  Select @TotalHoursByCategory = [TotalHours] From #TotalByCategory;  --< Note the table we are using

Select
   [CategoryID] = c.ID -- Will be handy for a later join!
  ,[CategoryName] = c.Name
  ,[TotalHoursByCategory] = Sum(Hrs)
  ,[TotalHours] = @TotalHoursByCategory

  ,[PercentByCategory] = Format(1. * (Sum(Hrs)) / @TotalHoursByCategory, '00.00%') 
Into  #CategoryContributions

From [EmployeeProjectHours] as eph
Join [Projects] as p On eph.ProjectID = p.ID
Join ProjectsCategories as pc On p.ID = pc.ProjectID
Join [Categories] as c On c.ID = pc.CategoryID
Group By c.ID, c.Name
Order By c.ID;
go

Select * From #CategoryContributions;
go

-- Great, that looks much better 


-- Next, lets select the total hours worked along with the total hours worked by PROJECTS.

--/* We need to be careful again! This runs, but gives the WRONG answer due to the double count!

Declare @TotalHours int
  Select @TotalHours = [TotalHours] From #TotalByProject; 

Select distinct
   [ProjectID] = p.ID
  ,[ProjectName] = p.Name
  ,[TotalHoursByProject] = Sum(Hrs) 
  ,[TotalHours] = @TotalHours
  ,[PercentByProject] = Format(1. * (Sum(Hrs)) / @TotalHours, '00.00%') 
From [EmployeeProjectHours] as eph
Join [Projects] as p On eph.ProjectID = p.ID
Join ProjectsCategories as pc On p.ID = pc.ProjectID
Join [Categories] as c On pc.CategoryID = c.ID  --<< We need to Remove this!
Group By p.ID, p.[Name]
Order By p.[ID];
go

----------------------------------------------------------------------------------------------
-- ProjectID	ProjectName	      TotalHoursByProject	TotalHours	PercentByProject
-- 100	      DW Planing	      2.00	              10	        20.00%
-- 200	      DW Implementation	3.00	              10	        30.00%
-- 300	      Document Update	  10.00	              10	        100.00%
----------------------------------------------------------------------------------------------

-- Here, is the correct way to get our results
If (Object_ID('tempdb..#ProjectContributions') is not null) Drop Table #ProjectContributions;
go

Declare @TotalHours int
  Select @TotalHours = [TotalHours] From #TotalByProject; 

Select distinct
   [ProjectID] = p.ID -- Will be handy for a later join!
  ,[ProjectName] = p.Name
  ,[TotalHoursByProject] = Sum(Hrs)
  ,[TotalHours] = @TotalHours
  ,[PercentByProject] = Format(1. * (Sum(Hrs)) / @TotalHours, '00.00%') 
Into #ProjectContributions
From [EmployeeProjectHours] as eph
Join [Projects] as p On eph.ProjectID = p.ID
Group By p.ID, p.Name
Order By p.ID;
go

Select * From #ProjectContributions Order By [ProjectID];


-- Lastly, we want to SELECT the relative percentages of both categories and projects.
-- we can uses our vHoursByProjectAndCategory view to join the data
Select * From #CategoryContributions;
Select * From #ProjectContributions;
Select * From vHoursByProjectAndCategory Order By CategoryID, ProjectID;
go

-- Here are all of the columns
Select * 
From vHoursByProjectAndCategory as eph
Join #CategoryContributions as c
  On eph.CategoryID = c.CategoryID
Join #ProjectContributions as p
  On eph.ProjectID  = p.ProjectID
go

-- Here are the ones I want in my reports
Select 
  c.CategoryName
, TotalHoursByCategory
, PercentByCategory
, p.ProjectName
, TotalHoursByProject
, PercentByProject
, p.TotalHours as TotalProjectHours
From vHoursByProjectAndCategory as eph
Join #CategoryContributions as c
  On eph.CategoryID = c.CategoryID
Join #ProjectContributions as p
  On eph.ProjectID  = p.ProjectID


-- Now, that I have what I want I will save it into a report table!
If (Object_ID('rptPrecentageHoursByCategoryAndProjects') is not null) Drop Table rptPrecentageHoursByCategoryAndProjects;
go
Select 
  c.CategoryName
, TotalHoursByCategory
, PercentByCategory
, p.ProjectName
, TotalHoursByProject
, PercentByProject
, p.TotalHours as TotalProjectHours
Into rptPrecentageHoursByCategoryAndProjects
From vHoursByProjectAndCategory as eph
Join #CategoryContributions as c
  On eph.CategoryID = c.CategoryID
Join #ProjectContributions as p
  On eph.ProjectID  = p.ProjectID


Select * From rptPrecentageHoursByCategoryAndProjects;

-- Now we have a report table, but to maintain it, we need to go though the process whenever the data changes. 
-- Let's create a reporting sproc to automate this process.
go
Create or Alter Proc pFillrptPrecentageHoursByCategoryAndProjects
--*************************************************************************--
-- Desc:This Sproc drops and recreates the rptPrecentageHoursByCategoryAndProjects 
-- table with fresh data 
-- Change Log: When,Who,What
-- 2020-01-01,RRoot,Created Sproc
--*************************************************************************--
As 
Begin
  Declare @RC int = 0;
  Begin Try
    
    -- Step 1: Get the Totals for both Categories and Projects

    If Object_ID('tempdb..#TotalByProject') is not null Drop Table #TotalByProject;
    If Object_ID('tempdb..#TotalByCategory') is not null Drop Table #TotalByCategory;
   
    Select 
    [TotalHours] = Sum(Hrs)
    Into #TotalByProject
    From EmployeeProjectHours

    Select 
    [TotalHours] = Sum(HoursWorked)
    Into #TotalByCategory
    From vHoursByProjectAndCategory

    Select [TotalHours] From #TotalByProject;
    Select [TotalHours] From #TotalByCategory;


    -- Step 2: Get Category aggregates
    If (Object_ID('tempdb..#CategoryContributions') is not null) Drop Table #CategoryContributions;
    Declare @TotalHoursByCategory int
      Select @TotalHoursByCategory = [TotalHours] From #TotalByCategory;  --< Note the table we are using
    Select
       [CategoryID] = c.ID -- Will be handy for a later join!
      ,[CategoryName] = c.Name
      ,[TotalHoursByCategory] = Sum(Hrs)
      ,[TotalHours] = @TotalHoursByCategory
      ,[PercentByCategory] = Format(1. * (Sum(Hrs)) / @TotalHoursByCategory, '00.00%') 
    Into  #CategoryContributions
    From [EmployeeProjectHours] as eph
    Join [Projects] as p On eph.ProjectID = p.ID
    Join ProjectsCategories as pc On p.ID = pc.ProjectID
    Join [Categories] as c On c.ID = pc.CategoryID
    Group By c.ID, c.Name
    Order By c.ID;

    -- Step 3: Get Project aggregates
    If (Object_ID('tempdb..#ProjectContributions') is not null) Drop Table #ProjectContributions;
    Declare @TotalHours int
      Select @TotalHours = [TotalHours] From #TotalByProject; 

    Select distinct
       [ProjectID] = p.ID -- Will be handy for a later join!
      ,[ProjectName] = p.Name
      ,[TotalHoursByProject] = Sum(Hrs)
      ,[TotalHours] = @TotalHours
      ,[PercentByProject] = Format(1. * (Sum(Hrs)) / @TotalHours, '00.00%') 
    Into #ProjectContributions
    From [EmployeeProjectHours] as eph
    Join [Projects] as p On eph.ProjectID = p.ID
    Group By p.ID, p.Name
    Order By p.ID;

    -- Step 4: Use Aggragetes to populate the report table 
    If (Object_ID('rptPrecentageHoursByCategoryAndProjects') is not null) Drop Table rptPrecentageHoursByCategoryAndProjects;
    Select 
      c.CategoryName
    , TotalHoursByCategory
    , PercentByCategory
    , p.ProjectName
    , TotalHoursByProject
    , PercentByProject
    , p.TotalHours as TotalProjectHours
    Into rptPrecentageHoursByCategoryAndProjects
    From vHoursByProjectAndCategory as eph
    Join #CategoryContributions as c
      On eph.CategoryID = c.CategoryID
    Join #ProjectContributions as p
      On eph.ProjectID  = p.ProjectID

    Set @RC = 1;
  End Try
  Begin Catch
    Print Error_Message()
    Set @RC = -1;
  End Catch
  Return @RC;
End
Go

-- Let's test the sproc!
Exec pFillrptPrecentageHoursByCategoryAndProjects;
go
Select * From rptPrecentageHoursByCategoryAndProjects;
go

-- Great! Now let's add more data and test again!
Select * From EmployeeProjectHours;
go
Insert Into EmployeeProjectHours
(EmployeeID, ProjectID, [Date], Hrs)
Values
(1, 100, '2020-01-02', 10)
go
Select * From EmployeeProjectHours;
go
Exec pFillrptPrecentageHoursByCategoryAndProjects;
go
Select * From rptPrecentageHoursByCategoryAndProjects;
go

-- Now that test worked, we would fill the database with the actual data. 