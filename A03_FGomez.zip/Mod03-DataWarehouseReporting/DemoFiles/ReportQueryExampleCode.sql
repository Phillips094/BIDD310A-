﻿/******************************************
Title:SalesByTitlesByDates
Description: Which titles were sold on which dates 
Developer:RRoot
Date: 6/1/2012

Change Log: Who, When, What
CMason,6/2/2013,fixed numerous grammatical errors
*******************************************/
Use DWPubsSales
go

SELECT 
    OrderNumber
  , OrderDateKey
  , TitleKey
  , StoreKey
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales
go

-- Very long query can get quite tedious to both read and write
SELECT
    DWPubsSales.dbo.DimTitles.TitleId
  , DWPubsSales.dbo.DimTitles.TitleName   
  , OrderNumber
  , OrderDateKey
  , DWPubsSales.dbo.FactSales.TitleKey
  , StoreKey
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales 
INNER JOIN DWPubsSales.dbo.DimTitles
  ON DWPubsSales.dbo.FactSales.TitleKey = DWPubsSales.dbo.DimTitles.TitleKey

-- Use table aliases to represent fully qualiﬁed names
SELECT 
    FS.TitleKey
  , DT.TitleName
  , OrderNumber
  , OrderDateKey
  , StoreKey
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey

-- The CONVERT Function can change data formats
SELECT
    DP.PublisherName 
  , [Title] = DT.TitleName
  , [TitleId] = DT.TitleId
  , [OrderDate] = CONVERT(varchar(50), [Date], 101)
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey
INNER JOIN DWPubsSales.dbo.DimDates AS DD
  ON FS.OrderDateKey = DD.DateKey
INNER JOIN DWPubsSales.dbo.DimPublishers AS DP
  ON DT.PublisherKey = DP.PublisherKey
ORDER BY DP.PublisherName, [Title], [OrderDate] 



-- Combining Multiple Operators in a WHERE Statement 
SELECT
    DP.PublisherName 
  , [Title] = DT.TitleName
  , [TitleId] = DT.TitleId
  , [OrderDate] = Convert(varchar(50), [Date], 101)
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey
INNER JOIN DWPubsSales.dbo.DimDates AS DD
  ON FS.OrderDateKey = DD.DateKey
INNER JOIN DWPubsSales.dbo.DimPublishers AS DP
  ON DT.PublisherKey = DP.PublisherKey
WHERE 
  [Date] BETWEEN '09/13/1994' AND '09/14/1994'
  AND 
  [TitleId] LIKE 'PS%' 
ORDER BY DP.PublisherName, [Title], [OrderDate]


-- Adding a Parameter Flag to Show All Data as Needed
DECLARE 
   @ShowAll nVarchar(4) = 'True'
 , @StartDate datetime = '09/13/1994'
 , @EndDate datetime = '09/14/1994'
 , @Prefix nVarchar(3) = 'PS%'

SELECT
    DP.PublisherName 
  , [Title] = DT.TitleName
  , [TitleId] = DT.TitleId
  , [OrderDate] = CONVERT(varchar(50), [Date], 101)
  , SalesQuantity
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey
INNER JOIN DWPubsSales.dbo.DimDates AS DD
  ON FS.OrderDateKey = DD.DateKey
INNER JOIN DWPubsSales.dbo.DimPublishers AS DP
  ON DT.PublisherKey = DP.PublisherKey
WHERE 
 @ShowAll = 'True'
 OR  
 [Date] BETWEEN @StartDate AND @EndDate
 AND 
 [TitleId] LIKE @Prefix
ORDER BY DP.PublisherName, [Title], [OrderDate]
 


-- Adding Aggregate Values to Our Results
DECLARE 
   @ShowAll nVarchar(4) = 'False'
 , @StartDate datetime = '09/13/1994'
 , @EndDate datetime = '09/14/1994'
 , @Prefix nVarchar(3) = 'PS%'
SELECT
    DP.PublisherName 
  , [Title] = DT.TitleName
  , [TitleId] = DT.TitleId
  , [OrderDate] = CONVERT(varchar(50), [Date], 101)
  , [Total for that Date by Title] = SUM(SalesQuantity)
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey
INNER JOIN DWPubsSales.dbo.DimDates AS DD
  ON FS.OrderDateKey = DD.DateKey
INNER JOIN DWPubsSales.dbo.DimPublishers AS DP
  ON DT.PublisherKey = DP.PublisherKey
WHERE 
 @ShowAll = 'True'
 OR  
 [Date] BETWEEN @StartDate AND @EndDate
 AND 
 [TitleId] LIKE @Prefix
GROUP BY
    DP.PublisherName 
  , DT.TitleName
  , DT.TitleId
  , [Date]
ORDER BY DP.PublisherName, [Title], [OrderDate]


-- Adding KPIs
DECLARE 
   @ShowAll nVarchar(4) = 'True'
 , @StartDate datetime = '09/13/1994'
 , @EndDate datetime = '09/14/1994'
 , @Prefix nVarchar(3) = 'PS%'
 , @AverageQty int
    SELECT @AverageQty = Avg(SalesQuantity) FROM DWPubsSales.dbo.FactSales

SELECT
    DP.PublisherName 
  , [Title] = DT.TitleName
  , [TitleId] = DT.TitleId
  , [OrderDate] = CONVERT(varchar(50), [Date], 101)
  , [Total for that Date by Title] = Sum(SalesQuantity)
  , [Average Qty in the FactSales Table] = @AverageQty
  , [KPI on Avg Quantity] = CASE
  WHEN Sum(SalesQuantity) 
    between (@AverageQty- 5) and (@AverageQty + 5) THEN 0
  WHEN Sum(SalesQuantity) < (@AverageQty- 5) THEN -1
  WHEN Sum(SalesQuantity) > (@AverageQty + 5) THEN 1
  END
FROM DWPubsSales.dbo.FactSales AS FS 
INNER JOIN DWPubsSales.dbo.DimTitles AS DT
  ON FS.TitleKey = DT.TitleKey
INNER JOIN DWPubsSales.dbo.DimDates AS DD
  ON FS.OrderDateKey = DD.DateKey
INNER JOIN DWPubsSales.dbo.DimPublishers AS DP
  ON DT.PublisherKey = DP.PublisherKey
WHERE 
 @ShowAll = 'True'
 OR  
 [Date] BETWEEN @StartDate AND @EndDate
 AND 
 [TitleId] LIKE @Prefix
GROUP BY
    DP.PublisherName 
  , DT.TitleName
  , DT.TitleId

  , CONVERT(varchar(50), [Date], 101)
ORDER BY DP.PublisherName, [Title], [OrderDate]
