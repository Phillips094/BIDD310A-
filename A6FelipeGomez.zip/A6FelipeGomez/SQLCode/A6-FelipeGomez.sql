/************************************************************** 
Title: Assignment06 Setup - Part 4
Description: This scipt create a view that shape the data to 
work with a MongoDB collection in assignment 06.
ChangeLog: When,Who,What
20201118,RRoot,Created Script
**************************************************************/

Use [DWNorthwindLite];
go

Create or Alter View vMongoDBExport
As
SELECT
 [_id] = ROW_NUMBER() OVER(ORDER BY OrderID ASC) 
,[OrderID]
,[CustomerID]
,[CustomerName]
,[CustomerCity]
,[CustomerCountry]
,[Date] = [DateKey]
,[USADateName] = REPLACE([USADateName], ',', ' -')
,[ProductID]
,[ProductName]
,[ProductCategoryID]
,[ProductCategoryName]
,[ActualOrderUnitPrice]
,[ActualOrderQuantity]
,[ExtendedPrice] = [ActualOrderUnitPrice] * [ActualOrderQuantity]
FROM [DWNorthwindLite].[dbo].[FactOrders] AS Orders 
INNER JOIN [DWNorthwindLite].[dbo].[DimCustomers] AS Customers ON Orders.CustomerKey = Customers.CustomerKey
INNER JOIN [DWNorthwindLite].[dbo].[DimDates] AS Dates ON Orders.OrderDateKey = Dates.DateKey
INNER JOIN [DWNorthwindLite].[dbo].[DimProducts] AS Products ON Orders.ProductKey = Products.ProductKey
ORDER BY OrderID ASC, ProductID ASC
OFFSET 0 ROWS
go

--********************************************************************--
-- Review the results of this script
--********************************************************************--
Select * from vMongoDBExport;

--********************************************************************--
-- Comparing Result from our vMongoDBExport export to our MongoDB Query
--********************************************************************--
--Select [OrderID], [CustomerID], [CustomerName], [ProductKey]
--From FactOrders as Orders Join DimCustomers as Customers
-- On Orders.CustomerKey = Customers.CustomerKey
--Where CustomerID = 'ALFKI'
